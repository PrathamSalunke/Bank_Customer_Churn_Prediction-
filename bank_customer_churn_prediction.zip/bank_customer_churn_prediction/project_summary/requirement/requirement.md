Business Requirements
Predict whether a customer will churn using both ML models and ANN.

Compare the performance of different models.

Identify key factors influencing churn and help banks take proactive measures.

Data Preprocessing: Droping irrelevant columns, Handling Outliers, encoding categorical variables, feature scaling.

Technical Requirements
Machine Learning Models
Train and compare different ML models:

Logistic Regression (Baseline model)

Decision Tree

Random Forest

XGBoost / LightGBM

Support Vector Machine (SVM)

Evaluate models using Accuracy, Precision, Recall, F1-score, and AUC-ROC Curve.

Artificial Neural Network (ANN)
Input Layer: Number of neurons = Number of processed features.

Hidden Layers: At least two hidden layers with ReLU activation.

Activation Functions:

Hidden layers → ReLU

Output layer → Sigmoid (binary classification).

Loss Function: Binary Crossentropy.

Optimizer: Adam (efficient weight updates).

Batch Size & Epochs: Tune for optimal performance.

Evaluation: Compare ANN performance with ML models using Confusion Matrix and AUC-ROC.

