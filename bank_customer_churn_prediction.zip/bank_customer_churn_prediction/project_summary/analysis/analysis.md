Problem Statement
Customer churn is a critical issue for banks as retaining customers is more cost-effective than acquiring new ones. The goal is to predict whether a customer will leave the bank based on historical data.

Dataset Overview
A typical dataset for churn prediction includes:

Customer Details: CustomerID, Name, Age, Gender, Geography

Account Information: Account Balance, Credit Score, Number of Products, Is Active Member

Transaction & Loan History: Tenure, Estimated Salary, Has Credit Card, Loan Status

Target Variable: Exited (1 = Yes, 0 = No)

Data Preprocessing 
Checking for null values.

Droping irrevelant columns 

Exploratory Data Analysis (EDA)
Distribution analysis of numerical and categorical variables.

Correlation matrix to identify influential features.

Feature Engineering 
Handled the outliers, applied encoding for categorical variables, applied standard scaler to particular numerical columns 

Model training and predicting 
Split into train and test data 

Applied traditional machine learning model, predict the output, Evaluated the model 

Initialized an ANN and added fully connected layers with ReLU/Sigmoid activations and dropout layers

Configured the model with Adam optimizer, binary cross-entropy loss function, and batch normalization to enhance stability and convergence

Trained the Ann, compared its accuracy with traditional machine learning model
